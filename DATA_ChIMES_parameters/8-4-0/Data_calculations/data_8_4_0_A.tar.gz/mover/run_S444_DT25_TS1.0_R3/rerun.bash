nohup mpirun -np 2 /home/dmartinezgutierrez/lmp_mpi_chimes_diego_intel_env_new -in input.in > test_AEMD_444_25.log&htop
